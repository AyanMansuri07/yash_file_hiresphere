from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.hashers import check_password, make_password
from .models import *

# Create your views here.
# def register(request):
    
#     if request.method == 'POST':
#         register=regi()
        
#         register.name = request.POST['name']
#         register.address = request.POST['address']
#         register.email = request.POST['email']
#         register.password = request.POST['password']
#         register.phone = request.POST['phone']
        
#         register.save()
#         print('2222222222222222222222222222222222222222')
#         request.session['email']=request.POST['email']
#         return render(request,'user_registration.html')
#     else:
#         return render(request,'user_registration.html')
    
# def cp_register_(request):
#     if request.method == 'POST':
#         register=cp_register()
        
#         register.cp_name = request.POST['name']
#         register.cp_address = request.POST['address']
#         register.cp_email = request.POST['email']
#         register.cp_password = request.POST['password']
#         register.cp_phone = request.POST['phone']
#         register.cp_gst_no = request.POST['cp_gstno']
#         register.save()
#         print('111111111111111111111111111111111111')
#         request.session['cp_email']=request.POST['email']
#         return render(request,'cp-register.html')
#     else:
#         return render(request,'cp-register.html')


# def login(request):

#     if 'email' in request.session:
#         if request.method == 'POST':
#             register=regi()
#             if regi.objects.filter(email= request.POST['email']):
            
#                 register.password == request.POST['password']
            
            
#                 return redirect('home')
#             else:
#                 return render(request,'user_login.html')
#         else:   
#             return render(request,'user_login.html')
#     elif 'cp_email' in request.session:
#         if request.method == 'POST':
#             register=cp_register()
#             if cp_register.objects.filter(cp_email= request.POST['email']):
                
#                 register.cp_password == request.POST['password']
                
                
#                 return redirect('home')
#             else:
#                 return render(request,'user_login.html')
#         else:   
#                 return render(request,'user_loginhtml')
#     else:   
#             return render(request,'user_login.html')


# Candidate Registration
def register(request):
    if request.method == 'POST':
        if regi.objects.filter(email=request.POST['email']).exists():
            return render(request, 'user_registration.html', {'error': 'Email already registered!'})
        
        candidate = regi()
        candidate.name = request.POST['name']
        candidate.address = request.POST['address']
        candidate.email = request.POST['email']
        candidate.password = make_password(request.POST['password'])  
        candidate.phone = request.POST['phone']
        candidate.save()
        
        request.session['email'] = candidate.email
        return render(request, 'user_registration.html', {'message': 'Candidate registration successful!'})
    
    return render(request, 'user_registration.html')

# Company Registration
def cpregister(request):
    if request.method == 'POST':
        if cp_register.objects.filter(cp_email=request.POST['email']).exists():
            return render(request, 'cp-register.html', {'error': 'Email already registered!'})
        
        company = cp_register()
        company.cp_name = request.POST['name']
        company.cp_address = request.POST['address']
        company.cp_email = request.POST['email']
        company.cp_password = make_password(request.POST['password'])  
        company.cp_phone = request.POST['phone']
        company.cp_gst_no = request.POST['gstno']
        company.save()
        
        request.session['cp_email'] = company.cp_email
        return render(request, 'cp-register.html', {'message': 'Company registration successful!'})
    
    return render(request, 'cp-register.html')

#  Login
def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        
        
        if regi.objects.filter(email=email).exists():
            print('yes')
            user = regi.objects.get(email=email)
            if check_password(password, user.password):
                user.name = user.name
                request.session['email'] = user.email
                print(111111111111111111)
                return render(request,'home.html',{'user':user.name})
            else:
                return render(request, 'user_login.html', {'error': 'Invalid password for candidate account.'})
        
        
        elif cp_register.objects.filter(cp_email=email).exists():
            
            company = cp_register.objects.get(cp_email=email)
            if check_password(password, company.cp_password):
                company.cp_name = company.cp_name
                request.session['cp_email'] = company.cp_email
                return render(request,'home.html',{'company':company.cp_name})
            else:
                return render(request, 'user_login.html', {'error': 'Invalid password for company account.'})
        
        # If email is not found in either table
        return render(request, 'user_login.html', {'error': 'Email not found.'})
    
    return render(request, 'user_login.html')



def home(request):
    return render(request,'home.html')
